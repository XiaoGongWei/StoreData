#include <iostream>
#include <stdio.h>
#include "People.h"
using namespace std;

void speakName(People *ppa)
{
    ppa->speakName();
}

int str2num(char *str, double *num)
{
    int allnum = 0;

    while('\0' != *str && '\n' != *str)
    {
        char bufstr[100] = {0};
        int flag = 0;
        while((' ' == *str || ',' == *str))
            str++;
        while(!(' ' == *str || ',' == *str))
        {
            if('\n'==*str || '\0' == *str)
                break;

            bufstr[flag] = *str;
            flag++;
            str++;

        }
        *num = atof(bufstr);
        num++;
        allnum++;
    }
    return allnum;
}

void readMat(char *filename)
{
    FILE *pid = fopen(filename, "r");
    if(NULL == pid)
        return ;
    while(!feof(pid))
    {
        char bufstr[1024]={0}, *shutchar;
        double bufnum[1024] = {0.0};
        int i = 0, allnum = 0;
        fgets(bufstr, 1024, pid);
        bufstr[1000] = '\0';
        shutchar = &bufstr[0];

        allnum = str2num(shutchar, bufnum);

        for(i = 0; i < allnum;i++)
            printf("%lf, ", bufnum[i]);

        printf("\n");

    }
    fclose(pid);
}

int main(int argc, char *argv[])
{
    // read matrix from txt
    readMat("/home/danid/mat.txt");

    // test for virtual function
    People *ppeo = NULL;

    ppeo = new david();
    speakName(ppeo);
    ((david *)ppeo)->speakName("AAAAAAAAAAAA");
    delete ppeo;

    ppeo  = new mawj();
    speakName(ppeo);
    delete ppeo;
    return 0;
}
