#ifndef PEOPLE_H
#define PEOPLE_H
#include <iostream>
#include <string>
#include <stdio.h>

using namespace std;

class People
{
public:
    People();
    virtual ~People();
    virtual void speakName()
    {
        cout << "i am People." << endl;
    }

public:
    string m_name;
    double m_whight;
    bool m_sex;
    double *m_leg;
};

class david: public People
{
public:
    david();
    ~david();
    void speakName();
    void speakName(string spk_str);
    double *m_david_leg;
};

class mawj: public People
{
public:
    mawj()
    {
        cout << "mawj()" << endl;
    }
    ~mawj()
    {
        cout << "~mawj()" << endl;

    }
    void speakName()
    {
        cout << " i am mawj" << endl;
    }

};

#endif // PEOPLE_H
