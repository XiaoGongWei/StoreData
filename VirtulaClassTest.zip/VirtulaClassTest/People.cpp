#include "People.h"

People::People()
{
    m_name = "admin";
    m_whight = 50;
    m_sex = 1;
    m_leg = new double(100);
}

People::~People()
{
    cout << "People::~People()  start" << endl;

    cout << "m_leg->" << 0 << "->" << m_leg[0] << endl;

    delete m_leg;

    cout << "People::~People()  11111111" << endl;
    cout << "m_leg->" << 0 << "->" << m_leg[0] << endl;

    cout << "People::~People()  end" << endl;
}

david::david()
{
    m_david_leg = new double(199);
    m_name = "david";
    m_leg[0] = 9999;
    m_sex = 1;

}

david::~david()
{
    cout << "david::~david()" << endl;
    cout << "david::~david() m_david_leg->" << m_david_leg << endl;
    delete m_david_leg;
    cout << "david::~david() m_david_leg->" << m_david_leg << endl;
}

void david::speakName()
{
    cout << "david::speakName() -> m_name:" << m_name << endl;
    cout << "david::speakName() -> m_leg:" << m_leg[0] << endl;
}


void david::speakName(string spk_str)
{
    char *p = "ABCD";
    int *in = new int(4);
    cout << sizeof(p) << p << endl;
    cout << sizeof(in) << *in << endl;
    cout << "david::speakName() -> m_name:" << spk_str << endl;
    delete in;
}

