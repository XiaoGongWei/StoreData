#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    readFile("/home/danid/mat.txt");

    connect(ui->pushButton, SIGNAL(clicked(bool)), this, SLOT(showFile()));

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::showFile()
{
    QString filename = QFileDialog::getOpenFileName();
    QFile fid(filename);
    fid.open(QFile::ReadOnly);
    QString all_text =  fid.readAll();
    ui->textEdit->setText(all_text);
}


void MainWindow::readFile(QString fileName)
{
    QFile fid(fileName);
    fid.open(QFile::Text | QFile::ReadOnly);
    if(!fid.isOpen())
        return;
//    QTextStream readIN(&fid);
    QString linestr = "";
    QStringList strlist;
    QVector<double> all_data;
    while (!fid.atEnd())
    {
//        readIN>>linestr;
        linestr = fid.readLine();
        QRegExp template_REG;
        QString str_split = "[ ]+";
        template_REG.setPattern(str_split);

        strlist = linestr.split(template_REG);
        for(int i = 0;i < strlist.length();i++)
        {
            double str_num = 0.0;
            QString temp_str = strlist.at(i);
            str_num = temp_str.toDouble();
            all_data.append(str_num);
        }


        all_data.clear();

    }





}
