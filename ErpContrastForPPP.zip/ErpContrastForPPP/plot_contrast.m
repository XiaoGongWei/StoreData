clear
clc
close all

load contrastData.mat

h1 = figure;

subplot(3,1,1)
title('has Erp or no Erp')
hold on
plot(diff_pos_erp(:, 1), 'b-.')
plot(diff_pos_noerp(:, 1), 'r.')
legend('Erp-dX', 'noErp-dX')
xlabel('epoch number')
ylabel('error Unit(m)')

subplot(3,1,2)
hold on
plot(diff_pos_erp(:, 2), 'b-.')
plot(diff_pos_noerp(:, 2), 'r.')
legend('Erp-dY', 'noErp-dY')
xlabel('epoch number')
ylabel('error Unit(m)')

subplot(3,1,3)
hold on
plot(diff_pos_erp(:, 3), 'b-.')
plot(diff_pos_noerp(:, 3), 'r.')
legend('Erp-dY', 'noErp-dY')
xlabel('epoch number')
ylabel('error Unit(m)')

h2 = figure;
hold on

error_erp = diff_pos_noerp - diff_pos_erp;
plot(error_erp)
legend('dY', 'dY', 'dZ')
xlabel('epoch number')
ylabel('error Unit(m)')
title('diffrent Erp and no Erp for PPP')





