function MyHeart()
%%this is ture picture of my heart 
[x,y,z]=meshgrid(linspace(-3,3));
val=(x.^2+(9/4).*y.^2+z.^2 - 1).^3-x.^(2).*z.^3-(9/80).*y.^2.*z.^3;
isosurface(x,y,z,val,0);set(patch(isosurface(x,y,z,val,0)),'FaceColor','r','EdgeColor','r');axis equal;
axis off
for i = 1:23
    if i <= 9
        Norm0(i);%�����Ŵ�
    elseif i >=10&&i <= 18
        Norm1(i)%��ת�Ŵ�
    elseif i>=19&&i<=20%��������ͼƬ �첽��ת
        clf
        if mod(i,2)==1
            Norm2_0
        elseif  mod(i,2)==0
            Norm2_1
        end
        Norm2(i)
    elseif i>=22&&i<=23%�ۺϵ��赸
        subplot(3,3,5)
        for k = 1:9
            Norm0(i);
        end
        for k = 1:9
            Norm1(i);
        end
    end
         
end