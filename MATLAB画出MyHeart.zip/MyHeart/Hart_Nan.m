function Hart_Nan()
%%this is ture picture of my heart 
clear
clc
[x,y,z]=meshgrid(linspace(-3,3));
val=(x.^2+(9/4).*y.^2+z.^2 - 1).^3-x.^(2).*z.^3-(9/80).*y.^2.*z.^3;
set(patch(isosurface(x,y,z,val,0)),'FaceColor','w','EdgeColor',[0.2 0.2 0.2]);
xlabel('x')
ylabel('y')
zlabel('z')

hold on
x = [0.7698 0.5851];
y = [0.3593 0.5492];
annotation('textarrow',x,y,'String','We are here.','FontSize',14);
%annotation('textarrow',x,y,'LineWidth',2,'Color','r');
line([0 -2],[0 0],[0 0],'LineWidth',2,'Color','r')
line([0 0],[0 -2],[0 0],'LineWidth',2,'Color','g')
line([0 0],[0 0],[0 2],'LineWidth',2,'Color','b')
view(-30,2)
