for k = 1:9  
    subplot(3,3,k)
    axis off
    [x,y,z]=meshgrid(linspace(-3,3));
    val=(x.^2+(9/4).*y.^2+z.^2 - 1).^3-x.^(2).*z.^3-(9/80).*y.^2.*z.^3;
    isosurface(x,y,z,val,0);
    if k <= 3
    set(patch(isosurface(x,y,z,val,0)),'FaceColor','r','EdgeColor','r');
    elseif k >= 4&&k <= 6
        set(patch(isosurface(x,y,z,val,0)),'FaceColor','g','EdgeColor','g');
    elseif k >= 7&&k <= 9
        set(patch(isosurface(x,y,z,val,0)),'FaceColor','b','EdgeColor','b');
    end
    axis equal;
    view(0,20)
    drawnow
end