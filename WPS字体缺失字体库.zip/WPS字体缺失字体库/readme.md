WPS字体缺失，把所有当前压缩包下的*.ttf和*.TTF 拷贝到/usr/share/fonts。命令: sudo cp *.ttf  /usr/share/fonts

author:xiaogongwei
E-mail:xiaogongwei10#163.com
